MESSAGE MANAGEMENT APP - NETBEANS QUICK START

FILES
- Main.java: the main menu and user input. Run this file to start the app.
- Message.java: represents one message and creates its SHA-256 hash.
- MessageManager.java: stores the five required lists and performs searches, deletion and reports.
- MessageManagerTest.java: runs 10 simple automated tests.
- stored_messages.json: example JSON file for the load feature.

NETBEANS STEPS
1. Open NetBeans.
2. Choose File > New Project.
3. Choose Java with Ant > Java Application (or Java Application if your version shows that).
4. Name the project MessageApp. Uncheck Create Main Class if NetBeans offers that option.
5. Under Source Packages, right-click the default package (or create a package named messageapp).
6. For the easiest setup, use the default package: right-click Source Packages > New > Java Class.
7. Create these four classes exactly: Main, Message, MessageManager, MessageManagerTest.
8. Open each matching .java file in this folder, copy all its code, and paste it into the matching NetBeans class. Do not add a package line.
9. Put stored_messages.json in the project root folder (the same level as nbproject and src, not inside Source Packages).
10. Right-click Main.java > Run File (or press Shift+F6). Use the Output window to type menu choices.
11. To test: right-click MessageManagerTest.java > Run File. All 10 tests should say PASS.

IMPORTANT
- Use JDK 8 or newer.
- If you create a named package instead of the default package, add the same package line at the very top of ALL four Java files.
- The app starts with empty message lists. Use Main menu option 1 to add messages. The test class loads the five assignment sample messages automatically.
- To load JSON, run the app from the project folder and choose Stored Messages > option 7.
